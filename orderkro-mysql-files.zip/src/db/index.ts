// src/db/index.ts
// Isse apne repo ki src/db/index.ts file REPLACE kar dijiye

import mysql from 'mysql2/promise';
import { drizzle } from 'drizzle-orm/mysql2';
import * as schema from './schema.ts';

declare global {
  var _mysqlPool: mysql.Pool | undefined;
}

export const createPool = () => {
  if (!global._mysqlPool) {
    global._mysqlPool = mysql.createPool({
      host: process.env.SQL_HOST || 'localhost',
      port: process.env.SQL_PORT ? parseInt(process.env.SQL_PORT) : 3306,
      user: process.env.SQL_USER || 'root',
      password: process.env.SQL_PASSWORD,
      database: process.env.SQL_DB_NAME,
      connectionLimit: 10,
    });
  }
  return global._mysqlPool;
};

const pool = createPool();
export const db = drizzle(pool, { schema, mode: 'default' });
