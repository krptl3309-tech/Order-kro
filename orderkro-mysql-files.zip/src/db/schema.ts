// src/db/schema.ts
// Isse apne repo ki src/db/schema.ts file REPLACE kar dijiye

import { mysqlTable, varchar, int, boolean, timestamp, decimal } from 'drizzle-orm/mysql-core';

export const products = mysqlTable('products', {
  id: varchar('id', { length: 191 }).primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  category: varchar('category', { length: 100 }).notNull(),
  subCategory: varchar('sub_category', { length: 100 }),
  price: int('price').notNull(),
  mrp: int('mrp').notNull(),
  weight: varchar('weight', { length: 50 }).notNull(),
  image: varchar('image', { length: 500 }).notNull(),
  rating: decimal('rating', { precision: 3, scale: 1 }).notNull().default('4.8'),
  reviewsCount: int('reviews_count').notNull().default(120),
  badge: varchar('badge', { length: 100 }),
  isOrganic: boolean('is_organic').default(false),
  inStock: boolean('in_stock').default(true),
  deliveryMinutes: int('delivery_minutes').notNull().default(9),
  description: varchar('description', { length: 1000 }),
  createdAt: timestamp('created_at').defaultNow(),
});

export const cartItems = mysqlTable('cart_items', {
  id: varchar('id', { length: 191 }).primaryKey(),
  userId: varchar('user_id', { length: 191 }).notNull().default('guest_user'),
  productId: varchar('product_id', { length: 191 }).notNull().references(() => products.id),
  quantity: int('quantity').notNull().default(1),
  updatedAt: timestamp('updated_at').defaultNow(),
});

export const orders = mysqlTable('orders', {
  id: varchar('id', { length: 191 }).primaryKey(),
  userId: varchar('user_id', { length: 191 }).notNull().default('guest_user'),
  status: varchar('status', { length: 50 }).notNull().default('OUT_FOR_DELIVERY'),
  totalPayable: int('total_payable').notNull(),
  itemTotal: int('item_total').notNull(),
  discount: int('discount').default(0),
  tip: int('tip').default(0),
  handlingFee: int('handling_fee').default(5),
  paymentMethod: varchar('payment_method', { length: 50 }).notNull().default('UPI'),
  deliveryAddress: varchar('delivery_address', { length: 1000 }).notNull(),
  instructions: varchar('instructions', { length: 500 }),
  riderName: varchar('rider_name', { length: 100 }).default('Ramesh Kumar'),
  riderPhone: varchar('rider_phone', { length: 20 }).default('+91 98765 43210'),
  etaMinutes: int('eta_minutes').default(6),
  createdAt: timestamp('created_at').defaultNow(),
});

export const orderItems = mysqlTable('order_items', {
  id: varchar('id', { length: 191 }).primaryKey(),
  orderId: varchar('order_id', { length: 191 }).notNull().references(() => orders.id),
  productId: varchar('product_id', { length: 191 }).notNull().references(() => products.id),
  quantity: int('quantity').notNull(),
  price: int('price').notNull(),
});
