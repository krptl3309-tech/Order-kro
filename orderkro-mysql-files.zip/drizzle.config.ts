// drizzle.config.ts
// Isse apne repo ke ROOT folder mein daaliye (Order-kro/drizzle.config.ts)

import { defineConfig } from 'drizzle-kit';
import dotenv from 'dotenv';

dotenv.config();

export default defineConfig({
  schema: './src/db/schema.ts',
  out: './drizzle',
  dialect: 'mysql',
  dbCredentials: {
    host: process.env.SQL_HOST || 'localhost',
    port: process.env.SQL_PORT ? parseInt(process.env.SQL_PORT) : 3306,
    user: process.env.SQL_USER || 'root',
    password: process.env.SQL_PASSWORD,
    database: process.env.SQL_DB_NAME!,
  },
});
